//
//  MyViewController.h
//  HelloiOS
//
//  Created by Ashiq uz Zoha on 12/12/13.
//  Copyright (c) 2013 BUET. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyViewController : UIViewController {
    NSArray *myArray ;
}


@property ( nonatomic , strong) IBOutlet UILabel *myLabel ;


- (IBAction) onClickButton : (id) sender ;

@end
