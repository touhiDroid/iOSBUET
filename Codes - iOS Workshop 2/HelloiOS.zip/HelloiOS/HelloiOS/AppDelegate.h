//
//  AppDelegate.h
//  HelloiOS
//
//  Created by Ashiq uz Zoha on 12/12/13.
//  Copyright (c) 2013 BUET. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
