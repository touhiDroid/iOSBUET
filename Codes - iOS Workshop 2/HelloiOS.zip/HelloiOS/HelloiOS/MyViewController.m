//
//  MyViewController.m
//  HelloiOS
//
//  Created by Ashiq uz Zoha on 12/12/13.
//  Copyright (c) 2013 BUET. All rights reserved.
//

#import "MyViewController.h"

@interface MyViewController ()

@end

@implementation MyViewController

@synthesize myLabel ;

- (IBAction) onClickButton : (id) sender {
    NSLog(@"My Button Clicked");
    
    int index = arc4random() % [myArray count];
    myLabel.text = [myArray objectAtIndex:index];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    myArray = [NSArray arrayWithObjects:@"CSE" , @"EEE", @"CE" , @"IPE" , nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
