//
//  AdmissionViewController.m
//  CSEBUET
//
//  Created by Ashiq uz Zoha on 12/13/13.
//  Copyright (c) 2013 BUET. All rights reserved.
//

#import "AdmissionViewController.h"

@interface AdmissionViewController ()

@end

@implementation AdmissionViewController

@synthesize infoLabel , segmentedControl ;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"Admission Info" ;
    self.infoLabel.text = @"This is BSc Admission Information" ;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction) onSegmentChanges :(id)sender  {

    int index = self.segmentedControl.selectedSegmentIndex ;
    
    NSLog(@"Current Selected Index = %d", index );
    
    if(index == 0){
        self.infoLabel.text = @"This is BSc Admission Information" ;
    } else {
        self.infoLabel.text = @"This is MSc Admission Information" ;
    }
}

@end
