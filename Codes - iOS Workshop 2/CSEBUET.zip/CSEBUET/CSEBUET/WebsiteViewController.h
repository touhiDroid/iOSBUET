//
//  WebsiteViewController.h
//  CSEBUET
//
//  Created by Ashiq uz Zoha on 12/13/13.
//  Copyright (c) 2013 BUET. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebsiteViewController : UIViewController <UIWebViewDelegate>

@property (nonatomic , strong) IBOutlet UIWebView *webView ;

@end
