//
//  FacultyViewController.m
//  CSEBUET
//
//  Created by Ashiq uz Zoha on 12/13/13.
//  Copyright (c) 2013 BUET. All rights reserved.
//

#import "FacultyViewController.h"
#import "FacultyCell.h"
#import "SVHTTPRequest.h"
#import "MyUtil.h"
#import "MBProgressHUD.h"

@interface FacultyViewController ()

@end

@implementation FacultyViewController {
    NSMutableArray *tableData ;
}
@synthesize TableView ;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"Faculty Members" ;
    
    tableData = [[NSMutableArray alloc] init];
    
    [self DownLoadDataFromServer];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1 ;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [tableData count] ;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    NSString *tableIdentifier = @"MyIdentifier" ;
    FacultyCell *cell = (FacultyCell*)[tableView dequeueReusableCellWithIdentifier:tableIdentifier];
    
    if(cell == nil){
        NSArray *nibs = [[NSBundle mainBundle] loadNibNamed:@"FacultyCell" owner:self options:nil];
        cell = [nibs objectAtIndex:0];
    }
    
    NSDictionary *celldic = [tableData objectAtIndex:indexPath.row];
    
    cell.nameLabel.text = [celldic objectForKey:@"name"];
    cell.designationLabel.text = [celldic objectForKey:@"designation"];
    cell.interestLabel.text = [celldic objectForKey:@"research_area"];
    
    NSString *url = [celldic objectForKey:@"image_link"];
    NSURL *URL = [[NSURL alloc] initWithString:url];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:URL];
    
    [MyUtil downloadImageWithURL: request completionBlock:^(BOOL succeeded, UIImage *image) {
        
        if(succeeded){
            cell.Photo.image = image ;
        }
        
    }];
    
    return cell ;
    
}

- (void) DownLoadDataFromServer {
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    NSString *url = @"http://shourav.com/cse-buet/get_teachers_info.php" ;
    
    SVHTTPRequest *request = [[SVHTTPRequest alloc] initWithAddress:url method:SVHTTPRequestMethodGET
                parameters:nil
                completion:^(id response, NSHTTPURLResponse *urlResponse, NSError *error) {
                    int statusCode = urlResponse.statusCode ;
                    NSLog(@"Status Code : %d" , statusCode);
                    NSLog(@"Response : %@" , [response class]);
                     NSArray *array = [NSJSONSerialization JSONObjectWithData:response options:kNilOptions error:&error];
                    NSLog(@"Array : %@" , array);
                    [MBProgressHUD hideHUDForView:self.view animated:YES];
                    [self ProcessData:array];
                }];
    
    [request start];
}

- (void) ProcessData : (NSArray*) result {

    if(result) {
    
        for ( NSDictionary *dic in result){
            [tableData addObject:dic];
        }
    }
    
    [self.TableView reloadData];
}

@end
















