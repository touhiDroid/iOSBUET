//
//  FacultyViewController.h
//  CSEBUET
//
//  Created by Ashiq uz Zoha on 12/13/13.
//  Copyright (c) 2013 BUET. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FacultyViewController : UIViewController <UITableViewDataSource , UITableViewDelegate>

@property (nonatomic , strong) IBOutlet UITableView *TableView ;

@end
