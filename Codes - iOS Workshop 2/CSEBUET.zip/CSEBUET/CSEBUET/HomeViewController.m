//
//  HomeViewController.m
//  CSEBUET
//
//  Created by Ashiq uz Zoha on 12/13/13.
//  Copyright (c) 2013 BUET. All rights reserved.
//

#import "HomeViewController.h"
#import "AboutViewController.h"
#import "WebsiteViewController.h"
#import "FacultyViewController.h"
#import "AdmissionViewController.h"

@interface HomeViewController ()

@end

@implementation HomeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"CSE BUET HOME" ;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction) onClickNoticeButton : (id)sender {

    NSLog(@"Notice Button Clicked");

}

- (IBAction) onClickFaculyButton : (id)sender {
    NSLog(@"Faculty Button Clicked");
    FacultyViewController *faculty = [[FacultyViewController alloc] initWithNibName:@"FacultyViewController" bundle:nil];
    [self.navigationController pushViewController:faculty animated:YES];
}

- (IBAction) onClickAdmissionButton : (id)sender {
    NSLog(@"Admission Button Clicked");
    
    AdmissionViewController *admission = [[AdmissionViewController alloc] initWithNibName:@"AdmissionViewController" bundle:nil];
    [self.navigationController pushViewController:admission animated:YES];
}

- (IBAction) onClickAboutButton : (id)sender {

    NSLog(@"About Button Clicked");
    AboutViewController *aboutViewController = [[AboutViewController alloc] initWithNibName:@"AboutViewController" bundle:nil];
    [self.navigationController pushViewController: aboutViewController animated:YES];
    
}

- (IBAction) onClickWebsiteButton : (id)sender {

    NSLog(@"Website Button Clicked");
    WebsiteViewController *websiteViewController = [[WebsiteViewController alloc] initWithNibName:@"WebsiteViewController" bundle:nil];
    [self.navigationController pushViewController:websiteViewController animated:YES];
}














@end
