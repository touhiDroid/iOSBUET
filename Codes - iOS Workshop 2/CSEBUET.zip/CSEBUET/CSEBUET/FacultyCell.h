//
//  FacultyCell.h
//  CSEBUET
//
//  Created by Ashiq uz Zoha on 12/13/13.
//  Copyright (c) 2013 BUET. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FacultyCell : UITableViewCell

@property (nonatomic , weak) IBOutlet UILabel *nameLabel ;
@property (nonatomic , weak) IBOutlet UILabel * designationLabel ;
@property (nonatomic , weak) IBOutlet UILabel *interestLabel ;

@property (nonatomic , weak) IBOutlet UIImageView *Photo ;


@end
