//
//  AdmissionViewController.h
//  CSEBUET
//
//  Created by Ashiq uz Zoha on 12/13/13.
//  Copyright (c) 2013 BUET. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AdmissionViewController : UIViewController

@property (nonatomic , strong) IBOutlet UILabel *infoLabel ;
@property (nonatomic , strong) IBOutlet UISegmentedControl *segmentedControl ;

- (IBAction) onSegmentChanges :(id)sender ;

@end
